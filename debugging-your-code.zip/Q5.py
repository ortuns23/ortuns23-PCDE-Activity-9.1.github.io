def factorial(n):
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result

# Test the function
print(factorial(5))  # Expected output: 120
