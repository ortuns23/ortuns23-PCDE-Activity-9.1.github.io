def add_underscores(word):
    underscored_word = ''
    for char in word:
        underscored_word += '_' + char
    underscored_word += '_'
    return underscored_word

# Test the function
print(add_underscores("python"))  # Output should be _p_y_t_h_o_n_

