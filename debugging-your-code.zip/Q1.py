global score
score = 0

def score():
    global score
    score = 0

score()
print(score)

