def buggy_function(x):
    if (x <= 10 and x % 2 == 0) or (x > 10 and x % 2 != 0):
        return True
    else:
        return False

# Test the function
print(buggy_function(14))  # Expected output: True

