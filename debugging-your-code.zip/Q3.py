def average(num1, num2):
    return (num1 + num2) / 2

# Test the function
print(average(4, 6))  # Expected output: 5.0
